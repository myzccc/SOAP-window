@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap_alimail/")
package soap_alimail;
